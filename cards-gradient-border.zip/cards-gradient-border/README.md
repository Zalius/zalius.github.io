# Cards (gradient border)

A Pen created on CodePen.io. Original URL: [https://codepen.io/zalius/pen/KKEvNOM](https://codepen.io/zalius/pen/KKEvNOM).

